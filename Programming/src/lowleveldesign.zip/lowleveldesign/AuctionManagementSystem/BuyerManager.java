package lowleveldesign.AuctionManagementSystem;

import java.util.List;

public class BuyerManager {
    List<Seller> buyerList;
    void registerBuyer(Buyer buyer) {}
}
