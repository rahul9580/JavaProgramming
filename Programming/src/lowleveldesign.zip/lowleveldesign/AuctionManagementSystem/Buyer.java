package lowleveldesign.AuctionManagementSystem;

public class Buyer {
    int buyerId;
    String name;
}
