package lowleveldesign.AuctionManagementSystem;

public class Bid {
    Buyer buyer;
    int amount;
}
