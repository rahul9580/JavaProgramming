package lowleveldesign.AuctionManagementSystem;

public class Seller {

    int sellerId;

    String name;

    int sellerBenefitAmount;

}
