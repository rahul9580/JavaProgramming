package lowleveldesign.AuctionManagementSystem;

public interface SellerAuctionService {
    void updateSellerBenefit(Seller seller, int benefitAmount);
}
