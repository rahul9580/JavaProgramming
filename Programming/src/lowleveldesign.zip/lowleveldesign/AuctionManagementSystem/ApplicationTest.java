package lowleveldesign.AuctionManagementSystem;

/*
auction management system


Create a seller

create a buyer

auction creation by a registered seller

bid on an auction by any registered buyer

bid amount can be updated by buyer

Withdraw bid

close an auction and return the winning bid

profit/loss of any seller till now

== maxbid- basebidamount - 10% of basebidamount

*/
public class ApplicationTest {

    public static void main(String[] args) {

    }
}
