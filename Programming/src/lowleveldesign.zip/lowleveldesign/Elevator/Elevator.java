package lowleveldesign.Elevator;

import java.util.TreeSet;

public class Elevator {
    int elevatorId;
    int currentFloorNo;
    Direction direction;
    TreeSet<Floor> destinations; //assending
    TreeSet<Floor> destinations; //desending
}
