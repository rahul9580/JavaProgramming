package lowleveldesign.Elevator;

import java.util.List;

public class ElevatorManager {
    List<Elevator> elevatorList;

    void registerElevator(Elevator elevator) {

    }

    int calculateDistance(Floor floor, Elevator elevator) {
        on 2
            4 8 1
            14 18 1
            dir down

                    MAx Floor: 10

        in 3
           ret 3
        4  8  1 3
        14 18 1 13

        if(elevator.currentFloorNo == floor.floorNo) {
            return 0;
        } else if (elevator.currentFloorNo < floor.floorNo){
            if(elevator.direction == Direction.DOWN) {
                return Integer.MAX_VALUE;
            } else {
                return Math.abs(elevator.currentFloorNo - floor.floorNo);
            }
        }

        return 1;


    }


}
