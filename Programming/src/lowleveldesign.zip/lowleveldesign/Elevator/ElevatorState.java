package lowleveldesign.Elevator;

public enum ElevatorState {
    STOP, RUNNING
}
