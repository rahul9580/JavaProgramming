package lowleveldesign.Elevator;

public enum Direction {
    UP, DOWN, NONE
}
