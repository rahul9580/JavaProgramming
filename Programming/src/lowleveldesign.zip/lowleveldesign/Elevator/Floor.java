package lowleveldesign.Elevator;

public class Floor {
    int floorNo;
}
