package lowleveldesign.Elevator;

/*
* On/Off
* Receive Event ( Floor no)
* Drop event (Floor no)
* Cancel event
* Weight Limit
* Register Elevator
* Position of elevator
* Define max no of flors
* Sync b/w elevator
* Rend nearest elevator going in same direction
*/
public class Test {
    public static void main(String[] args) {

    }
}
